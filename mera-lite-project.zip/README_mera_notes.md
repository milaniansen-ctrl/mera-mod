# MΞRA Client (Lite) 3.0.0

Fabric mod for Minecraft 1.21.11. Rebuilt from MΞRA Lite 2.0.0.

## What changed

- **Button above Singleplayer.** The "MΞRA Lite" button now sits directly above Singleplayer on the title screen, with the M logo on its left.
- **New look.** Left sidebar with the M logo and "MΞRA CLIENT", page buttons below it, and a content card on the right. Same violet and amber colours as the MΞRA launcher.
- **Marketplace:** search by pack or uploader, paging, pack description (read from the zip), and an "Installed" state.
- **Community:** submitting now checks the file (exists, .zip, up to 100 MB, really a resource pack). Pasted paths with quotes work. Staff submissions are approved right away.
- **Friends** is now a page inside the same window: add by name, remove with X, and see who is on your current server with their skin head. Players on the server can be added with one click.
- **Staff:** Approve and Reject (reject is new).
- **Profile:** name, role and stats.
- Your old data carries over: `config/friends-tab.json` and `config/mera-lite.json` use the same format.

## Build

1. Install JDK 21.
2. Open https://fabricmc.net/develop , pick Minecraft 1.21.11, and copy the Yarn, Loader, Loom and Fabric API versions into `gradle.properties`.
3. Add the Gradle wrapper (copy the `gradle` folder and `gradlew` files from the official fabric-example-mod, or run `gradle wrapper`).
4. Run `./gradlew build`. The jar is `build/libs/mera-lite-3.0.0.jar`.
5. Replace the old jar in your `mods` folder.

## Not tested

This source was written without being able to compile against Minecraft. It was only checked for Java syntax. Minecraft 1.21.11 renamed many things, so a name or two may not match your Yarn version. If Gradle reports an error, send me the message and I will fix it.
Things most likely to need a tweak: `Click` (mouse click event), `DrawContext.drawTextWithShadow`, and `client.getSession()`.
The skin-head lookup in `SkinCompat.java` uses reflection and falls back to a letter tile if it fails.
