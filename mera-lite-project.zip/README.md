# MΞRA Client (Lite) 3.0.0

Fabric mod for Minecraft 1.21.11, set up on the Fabric template (Yarn mappings, split client source set).

Build: `./gradlew build` (JDK 21+). Jar: `build/libs/mera-lite-3.0.0.jar`.
Or push to GitHub: the included Actions workflow builds it and uploads the jar as an artifact.

See README_mera_notes.md for the feature list. Source was never compiled against Minecraft,
so send any compiler errors back to get them fixed.
