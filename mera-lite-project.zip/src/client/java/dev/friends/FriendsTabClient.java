package dev.friends;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Identifier;

import java.util.List;

public class FriendsTabClient implements ClientModInitializer {
    public static final Identifier LOGO_16 = Identifier.of("friends_tab", "textures/gui/logo_16.png");
    public static final Identifier LOGO_32 = Identifier.of("friends_tab", "textures/gui/logo_32.png");

    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (!(screen instanceof TitleScreen)) return;

            List<ClickableWidget> buttons = Screens.getButtons(screen);

            // Sit directly above the Singleplayer button (same x, one row up). Fall back to the vanilla spot.
            int x = screen.width / 2 - 100;
            int y = screen.height / 4 + 24;
            for (ClickableWidget b : buttons) {
                if (b.getMessage().getContent() instanceof TranslatableTextContent t && "menu.singleplayer".equals(t.getKey())) {
                    x = b.getX();
                    y = b.getY() - 24;
                    break;
                }
            }

            ButtonWidget mera = ButtonWidget.builder(Text.literal("MΞRA Lite"), btn -> client.setScreen(new MeraLiteScreen(screen)))
                    .dimensions(x, y, 200, 20).build();
            buttons.add(mera);

            // Draw the M logo on the left side of the button.
            ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) ->
                    ctx.drawTexture(RenderPipelines.GUI_TEXTURED, LOGO_16, mera.getX() + 4, mera.getY() + 2, 0f, 0f, 16, 16, 16, 16));
        });
    }
}
