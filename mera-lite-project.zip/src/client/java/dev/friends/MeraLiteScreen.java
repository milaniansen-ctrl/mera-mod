package dev.friends;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * MΞRA Lite, revamped: a left sidebar with the M logo and page buttons, and a content card on the right.
 * Lists (packs, friends, approvals) are drawn by hand and clicked through "zones", so searching and
 * paging never rebuild the screen or steal keyboard focus.
 */
public class MeraLiteScreen extends Screen {
    public enum Page {
        MARKETPLACE("Marketplace"), COMMUNITY("Community"), FRIENDS("Friends"), PROFILE("Profile"), STAFF("Staff");
        final String label;
        Page(String label) { this.label = label; }
    }

    // MΞRA palette (ARGB; the alpha byte must be FF or text disappears in 1.21.6+)
    private static final int DIM = 0xD0080614, PANEL = 0xFF161326, SIDE = 0xFF110F20, LINE = 0xFF2C2748,
            CARD = 0xFF1E1A33, CARD_HOT = 0xFF2B2548, ACCENT = 0xFFA48BFF, ACCENT_DK = 0xFF5B4BA8,
            TEXT = 0xFFECE9F8, MUTED = 0xFF8F89B3, OK = 0xFF5EE6A8, BAD = 0xFFFF7A8A, AMBER = 0xFFFFB347;

    private static final int SIDEBAR = 100;
    private static final long MAX_PACK_BYTES = 100L * 1024 * 1024;

    private final Screen parent;
    private final Page page;
    private int subPage;
    private String search;
    private String notice = "";
    private int noticeColor = MUTED;

    private int px, py, pw, ph, cx, cw;
    private TextFieldWidget input;
    private boolean backgroundDone;
    private final List<Zone> zones = new ArrayList<>();
    private List<String> friends = new ArrayList<>();

    private record Zone(int x1, int y1, int x2, int y2, Runnable action) {
        boolean hit(double mx, double my) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }
    }
    private record Online(String name, Identifier skin) {}

    public MeraLiteScreen(Screen parent) { this(parent, Page.MARKETPLACE); }
    public MeraLiteScreen(Screen parent, Page page) { this(parent, page, 0, "", ""); }
    private MeraLiteScreen(Screen parent, Page page, int subPage, String search, String notice) {
        super(Text.literal("MΞRA Lite"));
        this.parent = parent; this.page = page; this.subPage = subPage; this.search = search; this.notice = notice;
    }

    /* ------------------------------------------------------------------ setup */

    @Override
    protected void init() {
        pw = Math.min(width - 16, 470);
        ph = Math.min(height - 16, 256);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        cx = px + SIDEBAR + 10;
        cw = pw - SIDEBAR - 18;
        friends = FriendStore.load();

        int ny = navTop();
        for (Page p : Page.values()) {
            if (p == Page.STAFF && !isStaff()) continue;
            addDrawableChild(ButtonWidget.builder(Text.literal(p.label), b -> open(p)).dimensions(px + 6, ny, SIDEBAR - 12, 18).build());
            ny += 21;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close()).dimensions(px + 6, py + ph - 24, SIDEBAR - 12, 18).build());

        switch (page) {
            case MARKETPLACE -> initSearch("Search packs");
            case COMMUNITY -> initCommunity();
            case FRIENDS -> initFriends();
            case STAFF -> initStaff();
            default -> { }
        }
    }

    private int navTop() { return py + 56; }
    private void open(Page p) { client.setScreen(new MeraLiteScreen(parent, p, 0, "", "")); }
    private void reopen() { client.setScreen(new MeraLiteScreen(parent, page, subPage, search, notice)); }

    private TextFieldWidget field(int x, int y, int w, String hint, String value) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 18, Text.literal(hint));
        f.setMaxLength(page == Page.COMMUNITY ? 260 : 40);
        f.setText(value);
        addDrawableChild(f);
        return f;
    }

    private void initSearch(String hint) {
        input = field(cx, py + 34, cw, hint, search);
        input.setChangedListener(s -> { search = s; subPage = 0; });
    }

    private void initCommunity() {
        input = field(cx, py + 34, cw - 64, "Path to a .zip resource pack", search);
        input.setMaxLength(260);
        input.setChangedListener(s -> search = s);
        addDrawableChild(ButtonWidget.builder(Text.literal("Submit"), b -> submitPack()).dimensions(cx + cw - 60, py + 34, 60, 18).build());
    }

    private void initFriends() {
        input = field(cx, py + 34, cw - 64, "Player name", search);
        input.setMaxLength(16);
        input.setChangedListener(s -> search = s);
        addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> addFriend(input.getText())).dimensions(cx + cw - 60, py + 34, 60, 18).build());
    }

    private void initStaff() {
        input = field(cx, py + 34, cw - 128, "Player name", search);
        input.setMaxLength(16);
        input.setChangedListener(s -> search = s);
        addDrawableChild(ButtonWidget.builder(Text.literal("Promote"), b -> updateStaff(true)).dimensions(cx + cw - 124, py + 34, 60, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Demote"), b -> updateStaff(false)).dimensions(cx + cw - 60, py + 34, 60, 18).build());
    }

    /* ------------------------------------------------------------------ who am I */

    private String currentUsername() {
        try { return client.getSession().getUsername(); } catch (Throwable t) { return "Player"; }
    }
    private boolean isStaff() { return isTrusted(currentUsername()); }
    private boolean isTrusted(String name) { return MeraStore.staff().stream().anyMatch(s -> s.equalsIgnoreCase(name)); }

    private void say(String msg, int color) { notice = msg; noticeColor = color; }

    /* ------------------------------------------------------------------ actions */

    private void install(PackSubmission p) {
        String name = p.fileName();
        if (!name.matches("[A-Za-z0-9._ ()\\-]{1,100}\\.zip")) { say("Invalid pack filename", BAD); return; }
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
            Files.createDirectories(dir);
            Path to = dir.resolve(name).normalize();
            if (!to.startsWith(dir.normalize())) { say("Invalid pack filename", BAD); return; }
            if (Files.exists(to)) { say("Already installed", AMBER); return; }
            Files.copy(p.source(), to);
            say("Installed to resourcepacks. Turn it on in Options > Resource Packs.", OK);
        } catch (IOException e) {
            say("Install failed: check the pack file", BAD);
        }
    }

    private boolean isInstalled(PackSubmission p) {
        return Files.exists(FabricLoader.getInstance().getGameDir().resolve("resourcepacks").resolve(p.fileName()));
    }

    private void submitPack() {
        String raw = search.trim();
        if (raw.length() > 1 && raw.startsWith("\"") && raw.endsWith("\"")) raw = raw.substring(1, raw.length() - 1); // "Copy as path" adds quotes
        Path file;
        try { file = Path.of(raw); } catch (Exception e) { say("That is not a valid path", BAD); return; }
        if (raw.isEmpty() || !Files.isRegularFile(file)) { say("Choose an existing .zip file", BAD); return; }
        if (!raw.toLowerCase(Locale.ROOT).endsWith(".zip")) { say("The file must end in .zip", BAD); return; }
        try { if (Files.size(file) > MAX_PACK_BYTES) { say("Packs can be up to 100 MB", BAD); return; } }
        catch (IOException e) { say("Could not read that file", BAD); return; }
        if (!PackInfo.isResourcePack(file)) { say("Not a resource pack: pack.mcmeta is missing", BAD); return; }
        final Path f = file;
        if (MeraStore.submissions().stream().anyMatch(s -> s.source().equals(f))) { say("You already submitted this pack", AMBER); return; }
        boolean staff = isStaff();
        MeraStore.submit(file, currentUsername(), staff);
        say(staff ? "Pack approved and added to the marketplace" : "Submitted for local staff review", OK);
        search = "";
        reopen();
    }

    private void addFriend(String name) {
        if (FriendStore.add(name)) { say(name.trim() + " added", OK); search = ""; reopen(); }
        else say("Enter a valid player name that is not already added", BAD);
    }
    private void removeFriend(String name) { FriendStore.remove(name); say(name + " removed", MUTED); reopen(); }

    private void updateStaff(boolean add) {
        String n = input == null ? "" : input.getText().trim();
        if (!n.matches("[A-Za-z0-9_]{1,16}")) { say("Enter a valid player name", BAD); return; }
        MeraStore.updateStaff(n, add);
        say(n + (add ? " promoted locally" : " demoted locally"), OK);
        search = "";
        reopen();
    }

    /* ------------------------------------------------------------------ drawing helpers */

    private void text(DrawContext c, String s, int x, int y, int color) { c.drawTextWithShadow(textRenderer, s, x, y, color); }
    private String fit(String s, int w) { return textRenderer.getWidth(s) <= w ? s : textRenderer.trimToWidth(s, w - 6) + "…"; }

    private void box(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x, y, x + w, y + h, border);
        c.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    /** A small clickable button that is drawn by hand (it does not exist as a widget). */
    private void zoneButton(DrawContext c, String label, int x, int y, int w, int h, int mx, int my, int color, boolean enabled, Runnable action) {
        boolean hot = enabled && mx >= x && mx < x + w && my >= y && my < y + h;
        box(c, x, y, w, h, hot ? ACCENT_DK : CARD, enabled ? color : LINE);
        int tw = textRenderer.getWidth(label);
        text(c, label, x + (w - tw) / 2, y + (h - 8) / 2, enabled ? TEXT : MUTED);
        if (enabled) zones.add(new Zone(x, y, x + w, y + h, action));
    }

    private void head(DrawContext c, int x, int y, String name, Identifier skin) {
        if (skin != null) {
            c.drawTexture(RenderPipelines.GUI_TEXTURED, skin, x, y, 8f, 8f, 8, 8, 64, 64);
            c.drawTexture(RenderPipelines.GUI_TEXTURED, skin, x, y, 40f, 8f, 8, 8, 64, 64);
        } else {
            c.fill(x, y, x + 8, y + 8, ACCENT_DK);
            String l = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
            text(c, l, x + 4 - textRenderer.getWidth(l) / 2, y, TEXT);
        }
    }

    private void heading(DrawContext c, String title, String sub) {
        text(c, title, cx, py + 10, TEXT);
        text(c, sub, cx, py + 21, MUTED);
    }

    private void footer(DrawContext c) {
        if (!notice.isEmpty()) text(c, fit(notice, cw), cx, py + ph - 14, noticeColor);
    }

    private void pager(DrawContext c, int mx, int my, int pages) {
        int y = py + ph - 28;
        int cxm = cx + cw / 2;
        String t = "Page " + (subPage + 1) + " / " + pages;
        text(c, t, cxm - textRenderer.getWidth(t) / 2, y + 5, MUTED);
        zoneButton(c, "<", cxm - 70, y, 20, 16, mx, my, LINE, subPage > 0, () -> subPage--);
        zoneButton(c, ">", cxm + 50, y, 20, 16, mx, my, LINE, subPage < pages - 1, () -> subPage++);
    }

    /* ------------------------------------------------------------------ render */

    /** Draws the vanilla menu background, then our panel. Guarded so Minecraft's one-blur-per-frame rule is respected. */
    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        if (backgroundDone) return;
        backgroundDone = true;
        super.renderBackground(c, mx, my, delta);
        c.fill(0, 0, width, height, DIM);
        box(c, px - 1, py - 1, pw + 2, ph + 2, PANEL, ACCENT_DK);
        c.fill(px, py, px + SIDEBAR, py + ph, SIDE);
        c.fill(px + SIDEBAR, py, px + SIDEBAR + 1, py + ph, LINE);
        c.drawTexture(RenderPipelines.GUI_TEXTURED, FriendsTabClient.LOGO_32, px + 10, py + 10, 0f, 0f, 32, 32, 32, 32);
        text(c, "MΞRA", px + 48, py + 13, TEXT);
        text(c, "CLIENT", px + 48, py + 25, ACCENT);
        c.fill(px + 8, py + 46, px + SIDEBAR - 8, py + 47, LINE);
        int ny = navTop();
        for (Page p : Page.values()) {
            if (p == Page.STAFF && !isStaff()) continue;
            if (p == page) c.fill(px, ny, px + 3, ny + 18, ACCENT);
            ny += 21;
        }
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        zones.clear();
        backgroundDone = false;
        renderBackground(c, mx, my, delta);
        super.render(c, mx, my, delta);

        text(c, "V3 | By Fakemarklol", px + 8, py + ph - 38, MUTED);

        switch (page) {
            case MARKETPLACE -> renderMarketplace(c, mx, my);
            case COMMUNITY -> renderCommunity(c, mx, my);
            case FRIENDS -> renderFriends(c, mx, my);
            case PROFILE -> renderProfile(c);
            case STAFF -> renderStaff(c, mx, my);
        }
        footer(c);
    }

    private void hint(DrawContext c, String s) {
        if (input != null && input.getText().isEmpty() && !input.isFocused()) text(c, s, input.getX() + 4, input.getY() + 5, MUTED);
    }

    /* ---- Marketplace */

    private List<PackSubmission> approved() {
        String q = search.toLowerCase(Locale.ROOT).trim();
        return MeraStore.submissions().stream().filter(PackSubmission::approved)
                .filter(p -> q.isEmpty() || p.fileName().toLowerCase(Locale.ROOT).contains(q) || p.uploader().toLowerCase(Locale.ROOT).contains(q))
                .sorted(Comparator.comparing(p -> p.fileName().toLowerCase(Locale.ROOT))).toList();
    }

    private String displayName(String file) {
        String n = file.endsWith(".zip") ? file.substring(0, file.length() - 4) : file;
        return n.replace('_', ' ');
    }

    private void renderMarketplace(DrawContext c, int mx, int my) {
        heading(c, "COMMUNITY RESOURCE MARKET", "Approved packs. One click to install.");
        hint(c, "Search packs or uploaders");
        List<PackSubmission> list = approved();
        int perPage = Math.max(1, (ph - 100) / 36);
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        subPage = Math.min(subPage, pages - 1);

        if (list.isEmpty()) {
            String a = search.isEmpty() ? "No approved packs yet" : "No packs match your search";
            text(c, a, cx + (cw - textRenderer.getWidth(a)) / 2, py + 90, TEXT);
            String b = search.isEmpty() ? "Approved uploads appear here for installation." : "Try a different name.";
            text(c, b, cx + (cw - textRenderer.getWidth(b)) / 2, py + 104, MUTED);
        }
        for (int i = 0; i < perPage; i++) {
            int idx = subPage * perPage + i;
            if (idx >= list.size()) break;
            PackSubmission p = list.get(idx);
            int y = py + 58 + i * 36;
            boolean hot = mx >= cx && mx < cx + cw && my >= y && my < y + 32;
            box(c, cx, y, cw, 32, hot ? CARD_HOT : CARD, LINE);
            c.fill(cx + 1, y + 1, cx + 3, y + 31, ACCENT);
            String desc = PackInfo.description(p.source());
            text(c, fit(displayName(p.fileName()), cw - 90), cx + 10, y + 6, TEXT);
            String by = "by " + p.uploader() + (isTrusted(p.uploader()) ? " ★" : "");
            text(c, fit(desc.isEmpty() ? by : by + "  ·  " + desc, cw - 90), cx + 10, y + 18, MUTED);
            boolean got = isInstalled(p);
            zoneButton(c, got ? "Installed" : "Install", cx + cw - 70, y + 7, 62, 18, mx, my, got ? OK : ACCENT, !got, () -> install(p));
        }
        pager(c, mx, my, pages);
    }

    /* ---- Community */

    private void renderCommunity(DrawContext c, int mx, int my) {
        heading(c, "SHARE A PACK", "Submit a local resource-pack ZIP for review.");
        hint(c, "Path to a .zip resource pack");
        text(c, "The file stays on this device in this prototype.", cx, py + 56, MUTED);

        text(c, "Your submissions", cx, py + 74, TEXT);
        String me = currentUsername();
        List<PackSubmission> mine = MeraStore.submissions().stream().filter(p -> p.uploader().equalsIgnoreCase(me)).toList();
        if (mine.isEmpty()) text(c, "No submissions", cx, py + 90, MUTED);
        int rows = Math.max(1, (ph - 130) / 20);
        for (int i = 0; i < Math.min(rows, mine.size()); i++) {
            PackSubmission p = mine.get(i);
            int y = py + 88 + i * 20;
            box(c, cx, y, cw, 18, CARD, LINE);
            text(c, fit(displayName(p.fileName()), cw - 100), cx + 6, y + 5, TEXT);
            String s = p.approved() ? "Approved" : "Pending review";
            text(c, s, cx + cw - 6 - textRenderer.getWidth(s), y + 5, p.approved() ? OK : AMBER);
        }
    }

    /* ---- Friends */

    private List<Online> onlinePlayers() {
        Map<String, Online> out = new LinkedHashMap<>();
        try {
            if (client.getNetworkHandler() != null) {
                for (PlayerListEntry e : client.getNetworkHandler().getPlayerList()) {
                    String n = e.getProfile().name();
                    out.put(n.toLowerCase(Locale.ROOT), new Online(n, SkinCompat.headTexture(e)));
                }
            }
        } catch (Throwable ignored) { }
        return new ArrayList<>(out.values());
    }

    private void renderFriends(DrawContext c, int mx, int my) {
        heading(c, "FRIENDS", friends.size() + (friends.size() == 1 ? " friend" : " friends"));
        hint(c, "Player name");

        List<Online> online = onlinePlayers();
        Map<String, Online> byName = new LinkedHashMap<>();
        for (Online o : online) byName.put(o.name().toLowerCase(Locale.ROOT), o);

        // rows: your friends first, then people on this server who are not your friends yet
        List<Object[]> rows = new ArrayList<>(); // {name, Online|null, isFriend}
        friends.stream().sorted(String.CASE_INSENSITIVE_ORDER).forEach(f -> rows.add(new Object[]{f, byName.get(f.toLowerCase(Locale.ROOT)), true}));
        for (Online o : online) if (friends.stream().noneMatch(f -> f.equalsIgnoreCase(o.name()))) rows.add(new Object[]{o.name(), o, false});

        int perPage = Math.max(1, (ph - 100) / 24);
        int pages = Math.max(1, (rows.size() + perPage - 1) / perPage);
        subPage = Math.min(subPage, pages - 1);
        if (rows.isEmpty()) {
            String a = "No friends yet";
            text(c, a, cx + (cw - textRenderer.getWidth(a)) / 2, py + 90, TEXT);
            String b = "Add a name above. Players on your server show up here.";
            text(c, fit(b, cw), cx + (cw - textRenderer.getWidth(fit(b, cw))) / 2, py + 104, MUTED);
        }
        for (int i = 0; i < perPage; i++) {
            int idx = subPage * perPage + i;
            if (idx >= rows.size()) break;
            String name = (String) rows.get(idx)[0];
            Online o = (Online) rows.get(idx)[1];
            boolean isFriend = (Boolean) rows.get(idx)[2];
            int y = py + 58 + i * 24;
            box(c, cx, y, cw, 21, CARD, LINE);
            head(c, cx + 6, y + 6, name, o == null ? null : o.skin());
            boolean staff = isTrusted(name);
            text(c, fit(name + (staff ? " ★" : ""), cw - 130), cx + 20, y + 6, isFriend ? TEXT : MUTED);
            String status = o != null ? "On this server" : "Offline";
            text(c, status, cx + cw - 30 - textRenderer.getWidth(status), y + 6, o != null ? OK : MUTED);
            if (isFriend) zoneButton(c, "X", cx + cw - 22, y + 3, 16, 15, mx, my, BAD, true, () -> removeFriend(name));
            else zoneButton(c, "+", cx + cw - 22, y + 3, 16, 15, mx, my, OK, true, () -> addFriend(name));
        }
        pager(c, mx, my, pages);
    }

    /* ---- Profile */

    private void renderProfile(DrawContext c) {
        String me = currentUsername();
        heading(c, "PLAYER PROFILE", "Your MΞRA Lite stats");
        box(c, cx, py + 40, cw, 52, CARD, LINE);
        c.fill(cx + 8, py + 48, cx + 44, py + 84, ACCENT_DK);
        String l = me.isEmpty() ? "?" : me.substring(0, 1).toUpperCase(Locale.ROOT);
        text(c, l, cx + 26 - textRenderer.getWidth(l) / 2, py + 62, TEXT);
        text(c, me + (isStaff() ? " ★" : ""), cx + 54, py + 52, TEXT);
        text(c, isStaff() ? "Staff member" : "Community member", cx + 54, py + 66, isStaff() ? AMBER : MUTED);

        List<PackSubmission> mine = MeraStore.submissions().stream().filter(p -> p.uploader().equalsIgnoreCase(me)).toList();
        long ok = mine.stream().filter(PackSubmission::approved).count();
        int tileW = (cw - 12) / 3;
        stat(c, 0, tileW, "Friends", String.valueOf(friends.size()));
        stat(c, 1, tileW, "Submitted", String.valueOf(mine.size()));
        stat(c, 2, tileW, "Approved", String.valueOf(ok));
    }

    private void stat(DrawContext c, int i, int w, String label, String value) {
        int x = cx + i * (w + 6), y = py + 104;
        box(c, x, y, w, 40, CARD, LINE);
        text(c, value, x + (w - textRenderer.getWidth(value)) / 2, y + 8, ACCENT);
        text(c, label, x + (w - textRenderer.getWidth(label)) / 2, y + 24, MUTED);
    }

    /* ---- Staff */

    private void renderStaff(DrawContext c, int mx, int my) {
        if (!isStaff()) { heading(c, "STAFF", "Staff access required"); return; }
        heading(c, "STAFF MANAGEMENT", "Local roles and pack approvals");
        hint(c, "Player name");
        text(c, "Staff roster", cx, py + 58, TEXT);
        text(c, fit(String.join(", ", MeraStore.staff()), cw), cx, py + 70, MUTED);
        text(c, "Pending pack approvals", cx, py + 88, TEXT);
        List<PackSubmission> pending = MeraStore.submissions().stream().filter(p -> !p.approved()).toList();
        if (pending.isEmpty()) text(c, "Queue is clear", cx, py + 102, MUTED);
        int rows = Math.max(1, (ph - 130) / 24);
        for (int i = 0; i < Math.min(rows, pending.size()); i++) {
            PackSubmission p = pending.get(i);
            int y = py + 100 + i * 24;
            box(c, cx, y, cw, 21, CARD, LINE);
            text(c, fit(displayName(p.fileName()) + " by " + p.uploader(), cw - 130), cx + 6, y + 6, TEXT);
            zoneButton(c, "Approve", cx + cw - 118, y + 3, 58, 15, mx, my, OK, true, () -> { MeraStore.approve(p); say("Approved " + displayName(p.fileName()), OK); });
            zoneButton(c, "Reject", cx + cw - 56, y + 3, 52, 15, mx, my, BAD, true, () -> { MeraStore.reject(p); say("Rejected " + displayName(p.fileName()), MUTED); });
        }
    }

    /* ------------------------------------------------------------------ input */

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            for (Zone z : new ArrayList<>(zones)) {
                if (z.hit(click.x(), click.y())) { z.action().run(); return true; }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public void close() { client.setScreen(parent); }
}
