package dev.friends;

import java.nio.file.Path;

/** A resource pack someone submitted to the local marketplace. */
public record PackSubmission(Path source, String uploader, boolean approved) {
    public String fileName() {
        Path n = source.getFileName();
        return n == null ? "" : n.toString();
    }
}
