package dev.friends;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Reads the short description out of a resource pack zip (pack.mcmeta). Results are cached. */
public final class PackInfo {
    private static final Map<Path, String> CACHE = new HashMap<>();
    private PackInfo() {}

    public static boolean isResourcePack(Path zip) {
        try (ZipFile z = new ZipFile(zip.toFile())) { return z.getEntry("pack.mcmeta") != null; }
        catch (Exception e) { return false; }
    }

    public static String description(Path zip) {
        return CACHE.computeIfAbsent(zip, p -> {
            if (!Files.isRegularFile(p)) return "";
            try (ZipFile z = new ZipFile(p.toFile())) {
                ZipEntry e = z.getEntry("pack.mcmeta");
                if (e == null) return "";
                try (var r = new InputStreamReader(z.getInputStream(e), StandardCharsets.UTF_8)) {
                    JsonObject pack = JsonParser.parseReader(r).getAsJsonObject().getAsJsonObject("pack");
                    JsonElement d = pack.get("description");
                    String s = d.isJsonPrimitive() ? d.getAsString()
                            : d.isJsonObject() && d.getAsJsonObject().has("text") ? d.getAsJsonObject().get("text").getAsString() : "";
                    return s.replaceAll("§.", "").replace('\n', ' ').trim();
                }
            } catch (Exception ex) { return ""; }
        });
    }
}
