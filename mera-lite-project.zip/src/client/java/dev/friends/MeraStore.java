package dev.friends;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Staff list and pack submissions, saved in config/mera-lite.json (same file as before). Local to this client. */
public final class MeraStore {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("mera-lite.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static final class StoredSubmission {
        String source; String uploader; boolean approved;
        StoredSubmission(String s, String u, boolean a) { source = s; uploader = u; approved = a; }
    }
    static final class Data {
        List<String> staff = new ArrayList<>();
        List<StoredSubmission> submissions = new ArrayList<>();
    }

    private MeraStore() {}

    private static Data load() {
        Data d = null;
        try { if (Files.exists(FILE)) d = GSON.fromJson(Files.readString(FILE), Data.class); } catch (Exception ignored) { }
        if (d == null) d = new Data();
        if (d.staff == null) d.staff = new ArrayList<>();
        if (d.submissions == null) d.submissions = new ArrayList<>();
        ensureDefaults(d);
        return d;
    }
    private static void ensureDefaults(Data d) {
        for (String s : List.of("_AlienMC", "Fakemarklol"))
            if (d.staff.stream().noneMatch(x -> x.equalsIgnoreCase(s))) d.staff.add(s);
    }
    private static void save(Data d) {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(d)); }
        catch (IOException ignored) { }
    }

    public static List<String> staff() { return new ArrayList<>(load().staff); }

    public static List<PackSubmission> submissions() {
        return load().submissions.stream()
                .filter(s -> s != null && s.source != null && s.uploader != null)
                .map(s -> new PackSubmission(Path.of(s.source), s.uploader, s.approved)).toList();
    }

    public static void submit(Path source, String uploader, boolean autoApprove) {
        Data d = load();
        d.submissions.add(new StoredSubmission(source.toString(), uploader, autoApprove));
        save(d);
    }
    public static void approve(PackSubmission p) {
        Data d = load();
        for (StoredSubmission s : d.submissions)
            if (s.source.equals(p.source().toString()) && s.uploader.equals(p.uploader())) s.approved = true;
        save(d);
    }
    public static void reject(PackSubmission p) {
        Data d = load();
        d.submissions.removeIf(s -> s.source.equals(p.source().toString()) && s.uploader.equals(p.uploader()));
        save(d);
    }
    public static void updateStaff(String name, boolean add) {
        Data d = load();
        d.staff.removeIf(x -> x.equalsIgnoreCase(name));
        if (add) d.staff.add(name);
        save(d);
    }
}
