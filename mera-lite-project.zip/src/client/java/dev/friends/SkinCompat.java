package dev.friends;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.MappingResolver;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;

/**
 * Finds a player's skin texture without depending on Minecraft's skin class names, which changed a lot in
 * recent versions. It calls the same methods the old MΞRA Lite jar used, looked up by their intermediary
 * names, so it works in the dev environment and in the real game. Returns null if anything is missing.
 */
final class SkinCompat {
    private SkinCompat() {}

    static Identifier headTexture(Object playerListEntry) {
        try {
            MappingResolver r = FabricLoader.getInstance().getMappingResolver();
            Object skin = call(r, playerListEntry, "net.minecraft.class_640", "method_52810", "()Lnet/minecraft/class_8685;");
            Object body = call(r, skin, "net.minecraft.class_8685", "comp_1626", "()Lnet/minecraft/class_12079$class_12081;");
            Object id = call(r, body, "net.minecraft.class_12079$class_12081", "comp_3627", "()Lnet/minecraft/class_2960;");
            return id instanceof Identifier i ? i : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Object call(MappingResolver r, Object target, String owner, String name, String desc) throws Exception {
        String cls = r.mapClassName("intermediary", owner);
        String method = r.mapMethodName("intermediary", owner, name, desc);
        Method m = Class.forName(cls).getMethod(method);
        m.setAccessible(true);
        return m.invoke(target);
    }
}
