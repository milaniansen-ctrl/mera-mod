package dev.friends;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Friends list, saved in config/friends-tab.json (same file and format as before, so old lists carry over). */
public final class FriendStore {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("friends-tab.json");
    private static final Gson GSON = new Gson();
    private static final Type LIST = new TypeToken<List<String>>() {}.getType();

    private FriendStore() {}

    public static List<String> load() {
        try {
            if (Files.exists(FILE)) {
                List<String> l = GSON.fromJson(Files.readString(FILE), LIST);
                if (l != null) return new ArrayList<>(l);
            }
        } catch (Exception ignored) { }
        return new ArrayList<>();
    }

    public static boolean add(String name) {
        name = name.trim();
        if (!name.matches("[A-Za-z0-9_]{1,16}")) return false;
        List<String> l = load();
        final String n = name;
        if (l.stream().anyMatch(x -> x.equalsIgnoreCase(n))) return false;
        l.add(name);
        save(l);
        return true;
    }

    public static void remove(String name) {
        List<String> l = load();
        l.removeIf(x -> x.equalsIgnoreCase(name));
        save(l);
    }

    private static void save(List<String> l) {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(l));
        } catch (IOException ignored) { }
    }
}
